import Postview from "./PostView/postview";
function App() {
  return (
    <div>
      <Postview/>
    </div>
  );
}

export default App;

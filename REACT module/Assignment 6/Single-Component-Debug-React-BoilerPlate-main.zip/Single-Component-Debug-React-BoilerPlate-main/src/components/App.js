
import React, {Component, useState} from "react";
import '../styles/App.css';

const App = () => {
  return (
    <div id="main">
      <p>Now I can render any React component on any DOM node I want using ReactDOM.render</p>
    </div>
  )
}
export default App;

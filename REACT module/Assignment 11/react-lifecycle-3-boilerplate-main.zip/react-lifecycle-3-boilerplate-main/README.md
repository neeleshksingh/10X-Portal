# Odd Even Mounting


There are two components defined in App.js named "Odd" and "Even"

and inside App only one is being displayed at a time which is then toggled by clicking the button.

Each time either component is Unmounted we want to print to console.

So By default when Even is being displayed and when we click the button
it should print to console "Even is unmounted" as even is removed, and instead Odd is being displayed
then again when we click the button Odd is removed so it should console.log "Odd is unmounted" and so on like that.

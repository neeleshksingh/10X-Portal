const start = document.getElementById("start");
const stop = document.getElementById("stop");
const pause = document.getElementById("pause");
const second = document.getElementById("seconds");
const hour = document.getElementById("hours");
let minute = document.getElementById("minutes");
let minuteVal= 0;
let secondVal = 0;
let hourVal = 0;
let secondInt,minuteInt,hourInt
stop.disabled = true;
pause.disabled = true;
start.addEventListener("click",()=>{
    start.disabled = true
    stop.disabled = false;
    pause.disabled = false;
    secondInt = setInterval(()=>{
        secondVal+=1;
        if(secondVal<10){
        second.innerText = "0"+secondVal
        }else{
            second.innerText = secondVal
        }
    },1000);
   minuteInt = setInterval(()=>{
        minuteVal+=1;
        if(minuteVal<10){
        minute.innerText = "0"+minuteVal
        }else{
            minute.innerText = minuteVal
        }
    },60000)
    hourInt = setInterval(()=>{
        hourVal+=1;
        if(hourVal<10){
            hour.innerText = "0"+hourVal
        }else{
            hour.innerText = hourVal
        }
    },3600000) 
})
pause.addEventListener("click",pauseTimer)
function pauseTimer(){
    clearInterval(secondInt);
    clearInterval(minuteInt);
    clearInterval(hourInt);

}
stop.addEventListener("click",()=>{
    clearInterval(secondInt);
    clearInterval(minuteInt);
    clearInterval(hourInt);
    second.innerText = "00"
    minute.innerText = "00"
    hour.innerText = "00"
})

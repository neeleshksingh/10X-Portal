import React from "react";
const Para = () =>{
    return(
        <p>I am learning React. My life is getting better.</p>
    )
} 
export default Para
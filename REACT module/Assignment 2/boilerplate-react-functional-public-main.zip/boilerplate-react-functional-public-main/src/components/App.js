import React, {Component, useState} from "react";
import '../styles/App.css';
import Para from "./para";
const App = () => {
  return (
    <div id="root">
      <Para/>
    </div>
  )
}
export default App;

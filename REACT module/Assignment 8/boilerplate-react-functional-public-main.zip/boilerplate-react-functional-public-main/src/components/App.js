import React, {Component, useState} from "react";
import '../styles/App.css';
import Form from "./form";

const App = () => {
  return (
    <div id="main">
      <Form/>
    </div>
  )
}


export default App;

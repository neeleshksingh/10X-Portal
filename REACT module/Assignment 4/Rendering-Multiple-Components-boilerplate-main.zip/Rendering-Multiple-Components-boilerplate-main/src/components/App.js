import React, {Component, useState} from "react";
import '../styles/App.css';
import Project from "./project";
const App = () => {
  return (
    <div id="main">
      <Project/>
    </div>
  )
}


export default App;

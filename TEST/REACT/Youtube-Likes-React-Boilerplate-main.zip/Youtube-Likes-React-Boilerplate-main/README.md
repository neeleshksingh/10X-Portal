# Youtube liker 

A svg file with name "like.svg" is given in the folder.
Using that make a clickable image(dont use button tag) with svg as src and id as "like-btn-img".(give an apt width)
Also display the number of likes like this "Likes: 0", the like number should be in a span 
with id ="like-counter".
Upon clicking the like image, the likes should also update.

Also the like img will have a background-color property which will initially be set to <code>rgba(255,0,0,0)</code>. Upon further click it will be <code>rgba(255,0,0,0.1)</code>, and on 2nd click when likes are 2 it will be
<code>rgba(255,0,0,0.2)</code> and so on like that.
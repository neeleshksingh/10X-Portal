# React Marco Polo

This mini project is to excercise your react state skills.
Create an h1 with id="marco-polo" which initially displays "Marco"
and a button with id="marco-polo-toggler" which initially displays "Polo"
inside the button.

On clicking the button the h1 should display "Polo" and the button should 
display "Marco" inside it, and so on like that".

On each button click, the h1 tag and text inside the button should alternate between "Marco" and "Polo"
